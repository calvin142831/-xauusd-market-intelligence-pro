self.addEventListener('install', event => { self.skipWaiting(); });
self.addEventListener('activate', event => { event.waitUntil(self.clients.claim()); });
self.addEventListener('push', event => {
  let data = {title: 'XAUUSD Market Alert', body: 'A new market update is available.', url: '/'};
  try { if (event.data) data = {...data, ...event.data.json()}; } catch (_) {}
  event.waitUntil(self.registration.showNotification(data.title, {
    body: data.body, icon: '/static/icons/icon-192.png', badge: '/static/icons/icon-192.png',
    data: {url: data.url || '/'}
  }));
});
self.addEventListener('notificationclick', event => {
  event.notification.close();
  const target = new URL(event.notification.data?.url || '/', self.location.origin).href;
  event.waitUntil(clients.matchAll({type:'window', includeUncontrolled:true}).then(list => {
    for (const client of list) if (client.url.startsWith(self.location.origin) && 'focus' in client) return client.focus();
    return clients.openWindow(target);
  }));
});

import os, sqlite3, time, json, threading, logging
from datetime import datetime, timezone
from flask import Flask, jsonify, render_template, request, send_from_directory
import requests
try:
    from pywebpush import webpush, WebPushException
except Exception:
    webpush = None
    WebPushException = Exception

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("xauusd-v4")

app = Flask(__name__)
DB = os.environ.get("DATABASE_PATH", "signals.db")
API_KEY = os.environ.get("TWELVEDATA_API_KEY", "")
SYMBOL = os.environ.get("MARKET_SYMBOL", "XAU/USD")
INTERVAL = os.environ.get("MARKET_INTERVAL", "5min")
CACHE = {"at": 0, "payload": None}
CACHE_SECONDS = int(os.environ.get("CACHE_SECONDS", "15"))

def db():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with db() as c:
        c.execute("""CREATE TABLE IF NOT EXISTS signals (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at TEXT NOT NULL, symbol TEXT NOT NULL,
            event TEXT NOT NULL, direction TEXT NOT NULL,
            score INTEGER, entry REAL, stop REAL,
            tp1 REAL, tp2 REAL, tp3 REAL, details TEXT
        )""")
        c.execute("""CREATE TABLE IF NOT EXISTS push_subscriptions (
            endpoint TEXT PRIMARY KEY, subscription TEXT NOT NULL, created_at TEXT NOT NULL
        )""")
        c.execute("""CREATE TABLE IF NOT EXISTS monitor_state (
            key TEXT PRIMARY KEY, value TEXT NOT NULL
        )""")
        c.execute("""CREATE TABLE IF NOT EXISTS tracked_setups (
            id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT NOT NULL, direction TEXT NOT NULL,
            entry REAL NOT NULL, stop REAL NOT NULL, tp1 REAL NOT NULL, tp2 REAL, tp3 REAL,
            candle_time INTEGER NOT NULL DEFAULT 0, outcome TEXT NOT NULL DEFAULT 'OPEN', closed_at TEXT
        )""")

def ema(values, period):
    if len(values) < period:
        return None
    alpha = 2 / (period + 1)
    result = values[0]
    for x in values[1:]:
        result = alpha * x + (1-alpha) * result
    return result

def rsi(values, period=14):
    if len(values) <= period:
        return None
    gains, losses = [], []
    for i in range(1, len(values)):
        d = values[i] - values[i-1]
        gains.append(max(d, 0))
        losses.append(max(-d, 0))
    avg_g = sum(gains[-period:]) / period
    avg_l = sum(losses[-period:]) / period
    if avg_l == 0:
        return 100.0
    return 100 - 100/(1 + avg_g/avg_l)

def analyze(candles):
    # Candles are oldest-first. This is a transparent confluence model,
    # not machine learning and not a statistically calibrated probability.
    if len(candles) < 60:
        return {"status": "warming_up", "message": "Waiting for at least 60 candles."}
    closes = [x["close"] for x in candles]
    highs = [x["high"] for x in candles]
    lows = [x["low"] for x in candles]
    last = candles[-1]
    prior = candles[-2]
    fast = ema(closes[-50:], 9)
    slow = ema(closes[-50:], 21)
    momentum = rsi(closes, 14)
    tr = []
    for i in range(1, len(candles)):
        tr.append(max(highs[i]-lows[i], abs(highs[i]-closes[i-1]), abs(lows[i]-closes[i-1])))
    atr = sum(tr[-14:])/min(14, len(tr)) if tr else 0
    lookback_high = max(highs[-21:-1])
    lookback_low = min(lows[-21:-1])
    bull_sweep = last["low"] < min(lows[-11:-1]) and last["close"] > min(lows[-11:-1])
    bear_sweep = last["high"] > max(highs[-11:-1]) and last["close"] < max(highs[-11:-1])
    bull_bos = last["close"] > lookback_high
    bear_bos = last["close"] < lookback_low
    bull_fvg = len(candles) >= 3 and last["low"] > candles[-3]["high"]
    bear_fvg = len(candles) >= 3 and last["high"] < candles[-3]["low"]
    bull_trend = fast is not None and slow is not None and fast > slow
    bear_trend = fast is not None and slow is not None and fast < slow
    bull_mom = momentum is not None and momentum > 51
    bear_mom = momentum is not None and momentum < 49
    bull_score = (2 if bull_trend else 0) + (1 if bull_mom else 0) + (2 if bull_sweep else 0) + (2 if bull_bos else 0) + (1 if bull_fvg else 0) + (1 if last["close"] > last["open"] else 0)
    bear_score = (2 if bear_trend else 0) + (1 if bear_mom else 0) + (2 if bear_sweep else 0) + (2 if bear_bos else 0) + (1 if bear_fvg else 0) + (1 if last["close"] < last["open"] else 0)
    direction = "BUY" if bull_score > bear_score else "SELL" if bear_score > bull_score else "NEUTRAL"
    score = max(bull_score, bear_score)
    # ATR-based indicative levels. Use only when a directional setup exists.
    entry = last["close"]
    if direction == "BUY":
        stop = min(entry - 1.6*atr, min(lows[-8:]) - 0.05*atr)
        risk = max(entry-stop, 0.5*atr)
        levels = {"entry": entry, "sl": stop, "tp1": entry+risk, "tp2": entry+2*risk, "tp3": entry+3*risk}
    elif direction == "SELL":
        stop = max(entry + 1.6*atr, max(highs[-8:]) + 0.05*atr)
        risk = max(stop-entry, 0.5*atr)
        levels = {"entry": entry, "sl": stop, "tp1": entry-risk, "tp2": entry-2*risk, "tp3": entry-3*risk}
    else:
        levels = {"entry": None, "sl": None, "tp1": None, "tp2": None, "tp3": None}
    return {
        "status": "ok", "direction": direction, "score": score,
        "bull_score": bull_score, "bear_score": bear_score,
        "rsi": round(momentum, 1) if momentum is not None else None,
        "ema_fast": fast, "ema_slow": slow, "atr": atr,
        "liquidity": "LOW SWEEP" if bull_sweep else "HIGH SWEEP" if bear_sweep else "No sweep detected",
        "structure": "BULLISH BOS" if bull_bos else "BEARISH BOS" if bear_bos else "No confirmed break",
        "fvg": "BULLISH FVG" if bull_fvg else "BEARISH FVG" if bear_fvg else "None detected",
        **levels
    }

def fetch_candles(interval, outputsize=220):
    if not API_KEY:
        raise RuntimeError("Missing TWELVEDATA_API_KEY. Add your Twelve Data API key to the hosting environment.")
    r = requests.get("https://api.twelvedata.com/time_series", params={
        "symbol": SYMBOL, "interval": interval, "outputsize": outputsize,
        "timezone": "UTC", "apikey": API_KEY
    }, timeout=15)
    data = r.json()
    if r.status_code != 200 or "values" not in data:
        raise RuntimeError(data.get("message", data.get("code", "Market data provider error")))
    vals = list(reversed(data["values"]))
    candles = []
    for v in vals:
        stamp = v["datetime"]
        if "T" in stamp:
            dt = datetime.fromisoformat(stamp.replace("Z", "+00:00"))
            if dt.tzinfo is None: dt = dt.replace(tzinfo=timezone.utc)
        else:
            dt = datetime.strptime(stamp, "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone.utc)
        candles.append({"time": int(dt.timestamp()), "open": float(v["open"]),
            "high": float(v["high"]), "low": float(v["low"]),
            "close": float(v["close"]), "volume": float(v.get("volume") or 0)})
    return candles

def get_market(force=False):
    now = time.time()
    if not force and CACHE["payload"] and now - CACHE["at"] < CACHE_SECONDS:
        return CACHE["payload"], None
    try:
        candles = fetch_candles(INTERVAL, 250)
        analysis = analyze(candles)
        # Higher-timeframe trend confirmation. Separate provider calls are subject to plan limits.
        frames = {INTERVAL: analysis}
        for tf in ("15min", "1h"):
            try: frames[tf] = analyze(fetch_candles(tf, 180))
            except Exception as exc: frames[tf] = {"status": "unavailable", "message": str(exc)}
        higher = [x.get("direction") for k, x in frames.items() if k != INTERVAL and x.get("status") == "ok"]
        alignment = sum(1 for d in higher if d == analysis.get("direction") and d != "NEUTRAL")
        analysis["timeframes"] = {k: {"direction": v.get("direction", "N/A"), "score": v.get("score")} for k, v in frames.items()}
        analysis["higher_timeframe_alignment"] = alignment
        analysis["mtf_status"] = "ALIGNED" if alignment == 2 else "PARTIAL" if alignment == 1 else "MIXED / UNCONFIRMED"
        payload = {"symbol": SYMBOL, "interval": INTERVAL, "candles": candles,
            "analysis": analysis, "provider": "Twelve Data", "updated_at": datetime.now(timezone.utc).isoformat()}
        CACHE.update({"at": now, "payload": payload})
        return payload, None
    except Exception as e:
        return None, f"Could not retrieve market data: {str(e)}"

def log_background_signal(event, a, detail=""):
    with db() as c:
        c.execute("""INSERT INTO signals (created_at,symbol,event,direction,score,entry,stop,tp1,tp2,tp3,details)
            VALUES (?,?,?,?,?,?,?,?,?,?,?)""", (datetime.now(timezone.utc).isoformat(), SYMBOL, event,
            a.get("direction", ""), a.get("score"), a.get("entry"), a.get("sl"), a.get("tp1"),
            a.get("tp2"), a.get("tp3"), detail or a.get("mtf_status", "")))

def send_push(title, body, url="/"):
    if not (webpush and os.getenv("VAPID_PRIVATE_KEY") and os.getenv("VAPID_PUBLIC_KEY")):
        return
    with db() as c: subs = c.execute("SELECT endpoint,subscription FROM push_subscriptions").fetchall()
    for row in subs:
        try:
            webpush(subscription_info=json.loads(row["subscription"]), data=json.dumps({"title":title,"body":body,"url":url}),
                vapid_private_key=os.environ["VAPID_PRIVATE_KEY"],
                vapid_claims={"sub":os.getenv("VAPID_CLAIMS_EMAIL","mailto:admin@example.com")})
        except WebPushException as exc:
            if getattr(exc, "response", None) is not None and exc.response.status_code in (404,410):
                with db() as c: c.execute("DELETE FROM push_subscriptions WHERE endpoint=?", (row["endpoint"],))
            log.warning("Push delivery failed: %s", exc)
        except Exception as exc: log.warning("Push error: %s", exc)

def background_monitor():
    interval = max(30, int(os.getenv("MONITOR_INTERVAL_SECONDS", "60")))
    while True:
        try:
            payload, error = get_market(force=True)
            if payload and payload["analysis"].get("status") == "ok":
                a = payload["analysis"]; candle = payload["candles"][-1]
                key = f"{candle['time']}:{a.get('direction')}"
                with db() as c:
                    old = c.execute("SELECT value FROM monitor_state WHERE key='last_signal_key'").fetchone()
                # Resolve active setup outcomes using each newly fetched candle. If SL and TP1
                # are both touched in the same OHLC candle, use the conservative SL-first rule.
                with db() as c:
                    open_rows = c.execute("SELECT * FROM tracked_setups WHERE outcome='OPEN'").fetchall()
                    for trade in open_rows:
                        if candle["time"] <= trade["candle_time"]: continue
                        result = None
                        if trade["direction"] == "BUY":
                            if candle["low"] <= trade["stop"]: result = "SL"
                            elif candle["high"] >= trade["tp1"]: result = "TP1"
                        else:
                            if candle["high"] >= trade["stop"]: result = "SL"
                            elif candle["low"] <= trade["tp1"]: result = "TP1"
                        if result:
                            c.execute("UPDATE tracked_setups SET outcome=?,closed_at=? WHERE id=?", (result, datetime.now(timezone.utc).isoformat(), trade["id"]))
                            c.execute("INSERT INTO signals(created_at,symbol,event,direction,entry,stop,tp1,details) VALUES(?,?,?,?,?,?,?,?)", (datetime.now(timezone.utc).isoformat(), SYMBOL, trade["direction"] + " " + result, trade["direction"], trade["entry"], trade["stop"], trade["tp1"], "Outcome tracker"))
                if a.get("direction") in ("BUY", "SELL") and a.get("score",0) >= 6 and a.get("higher_timeframe_alignment",0) >= 1 and (not old or old["value"] != key):
                    event = a["direction"] + " CONFIRMED"
                    log_background_signal(event, a, "Background scan · " + a.get("mtf_status", ""))
                    if all(a.get(k) is not None for k in ("entry", "sl", "tp1")):
                        with db() as c: c.execute("INSERT INTO tracked_setups(created_at,direction,entry,stop,tp1,tp2,tp3,candle_time) VALUES(?,?,?,?,?,?,?,?)", (datetime.now(timezone.utc).isoformat(), a["direction"], a["entry"], a["sl"], a["tp1"], a.get("tp2"), a.get("tp3"), candle["time"]))
                    with db() as c: c.execute("INSERT OR REPLACE INTO monitor_state(key,value) VALUES('last_signal_key',?)", (key,))
                    send_push("XAUUSD " + event, f"Score {a['score']}/9 · MTF {a['mtf_status']} · Entry {a.get('entry')} · SL {a.get('sl')} · TP1 {a.get('tp1')}")
        except Exception as exc: log.exception("Background scan failed: %s", exc)
        time.sleep(interval)


@app.route("/")
def index():
    return render_template("index.html")

@app.route("/manifest.webmanifest")
def manifest():
    return send_from_directory("static", "manifest.webmanifest", mimetype="application/manifest+json")

@app.route("/sw.js")
def service_worker():
    return send_from_directory("static", "sw.js", mimetype="application/javascript")

@app.route("/api/push/config")
def push_config():
    return jsonify({"publicKey": os.getenv("VAPID_PUBLIC_KEY", ""), "enabled": bool(webpush and os.getenv("VAPID_PUBLIC_KEY") and os.getenv("VAPID_PRIVATE_KEY"))})

@app.route("/api/push/subscribe", methods=["POST"])
def push_subscribe():
    d = request.get_json(silent=True) or {}; sub = d.get("subscription")
    if not isinstance(sub, dict) or not sub.get("endpoint"):
        return jsonify({"error":"Invalid push subscription"}), 400
    with db() as c: c.execute("INSERT OR REPLACE INTO push_subscriptions(endpoint,subscription,created_at) VALUES(?,?,?)", (sub["endpoint"], json.dumps(sub), datetime.now(timezone.utc).isoformat()))
    return jsonify({"saved":True})

@app.route("/api/market")
def market():
    payload, error = get_market()
    if error:
        return jsonify({"error": error, "configured": bool(API_KEY)}), 503
    return jsonify(payload)

@app.route("/api/signals")
def signals():
    with db() as c:
        rows = c.execute("SELECT * FROM signals ORDER BY id DESC LIMIT 100").fetchall()
    return jsonify([dict(x) for x in rows])

@app.route("/api/performance")
def performance():
    with db() as c:
        rows = c.execute("SELECT outcome,COUNT(*) AS n FROM tracked_setups WHERE outcome!='OPEN' GROUP BY outcome").fetchall()
        opened = c.execute("SELECT COUNT(*) FROM tracked_setups WHERE outcome='OPEN'").fetchone()[0]
        total = sum(x["n"] for x in rows); wins = sum(x["n"] for x in rows if x["outcome"].startswith("TP")); losses = sum(x["n"] for x in rows if x["outcome"] == "SL")
    return jsonify({"closed":total,"wins":wins,"losses":losses,"open":opened,"win_rate":round(100*wins/total,1) if total else None,"note":"Historical outcomes from monitored OHLC candles; not a verified broker fill or live trading return."})

@app.route("/api/signals/log", methods=["POST"])
def log_signal():
    from flask import request
    d = request.get_json(silent=True) or {}
    allowed = {"EARLY BUY","EARLY SELL","BUY CONFIRMED","SELL CONFIRMED","BUY TP1","BUY TP2","BUY TP3","BUY SL","SELL TP1","SELL TP2","SELL TP3","SELL SL"}
    if d.get("event") not in allowed:
        return jsonify({"error":"Invalid event"}), 400
    with db() as c:
        c.execute("""INSERT INTO signals
            (created_at,symbol,event,direction,score,entry,stop,tp1,tp2,tp3,details)
            VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
            (datetime.now(timezone.utc).isoformat(), SYMBOL, d["event"],
             d.get("direction",""), d.get("score"), d.get("entry"), d.get("sl"),
             d.get("tp1"), d.get("tp2"), d.get("tp3"), d.get("details","")))
    return jsonify({"saved": True})

@app.route("/health")
def health():
    return jsonify({"ok": True, "market_key_configured": bool(API_KEY), "push_configured": bool(webpush and os.getenv("VAPID_PUBLIC_KEY") and os.getenv("VAPID_PRIVATE_KEY")), "background_monitor": True})

init_db()
# Single Gunicorn worker is configured in render.yaml so this scanner runs once per service.
_monitor_started = False
_monitor_lock = threading.Lock()
def start_monitor_once():
    global _monitor_started
    with _monitor_lock:
        if not _monitor_started and os.getenv("DISABLE_BACKGROUND_MONITOR", "0") != "1":
            threading.Thread(target=background_monitor, name="xauusd-monitor", daemon=True).start()
            _monitor_started = True
start_monitor_once()
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)), debug=False)

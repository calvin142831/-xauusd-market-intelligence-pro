import os, sqlite3, time, json, threading, logging
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from flask import Flask, jsonify, render_template, request, send_from_directory
import requests
try:
    from pywebpush import webpush, WebPushException
except Exception:
    webpush = None
    WebPushException = Exception

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("xauusd-black-pro-v12")

app = Flask(__name__)
DB = os.environ.get("DATABASE_PATH", "signals.db")
API_KEY = os.environ.get("TWELVEDATA_API_KEY", "")
SYMBOL = os.environ.get("MARKET_SYMBOL", "XAU/USD")
INTERVAL = os.environ.get("MARKET_INTERVAL", "1min")
CACHE = {"at": 0, "payload": None}
CACHE_SECONDS = max(5, int(os.environ.get("CACHE_SECONDS", "10")))
PROVIDER_TIMEOUT = max(3, float(os.environ.get("PROVIDER_TIMEOUT_SECONDS", "8")))
PROVIDER_RETRIES = max(0, min(2, int(os.environ.get("PROVIDER_RETRIES", "1"))))
STALE_MAX_SECONDS = max(60, int(os.environ.get("STALE_MAX_SECONDS", "300")))
LAST_PROVIDER_ERROR = {"message": None, "at": None}
HTF_CACHE = {"at": 0, "frames": {}}
MARKET_LOCK = threading.Lock()
HTF_LOCK = threading.Lock()

def db():
    conn = sqlite3.connect(DB, timeout=10)
    conn.execute("PRAGMA busy_timeout=10000")
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with db() as c:
        c.execute("PRAGMA journal_mode=WAL")
        c.execute("""CREATE TABLE IF NOT EXISTS signals (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at TEXT NOT NULL, symbol TEXT NOT NULL,
            event TEXT NOT NULL, direction TEXT NOT NULL,
            score INTEGER, entry REAL, stop REAL,
            tp1 REAL, tp2 REAL, tp3 REAL, details TEXT
        )""")
        c.execute("""CREATE TABLE IF NOT EXISTS push_subscriptions (
            endpoint TEXT PRIMARY KEY, subscription TEXT NOT NULL, created_at TEXT NOT NULL
        )""")
        c.execute("""CREATE TABLE IF NOT EXISTS monitor_state (
            key TEXT PRIMARY KEY, value TEXT NOT NULL
        )""")
        c.execute("""CREATE TABLE IF NOT EXISTS tracked_setups (
            id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT NOT NULL, direction TEXT NOT NULL,
            entry REAL NOT NULL, stop REAL NOT NULL, tp1 REAL NOT NULL, tp2 REAL, tp3 REAL,
            candle_time INTEGER NOT NULL DEFAULT 0, outcome TEXT NOT NULL DEFAULT 'OPEN', closed_at TEXT
        )""")
        c.execute("CREATE INDEX IF NOT EXISTS idx_signals_created_at ON signals(id DESC)")
        c.execute("CREATE INDEX IF NOT EXISTS idx_tracked_outcome ON tracked_setups(outcome)")

def ema(values, period):
    if len(values) < period:
        return None
    alpha = 2.0 / (period + 1)
    result = sum(values[:period]) / period
    for value in values[period:]:
        result = alpha * value + (1 - alpha) * result
    return result


def rsi(values, period=14):
    if len(values) <= period:
        return None
    changes = [values[i] - values[i - 1] for i in range(1, len(values))]
    gains = [max(x, 0.0) for x in changes]
    losses = [max(-x, 0.0) for x in changes]
    avg_gain = sum(gains[:period]) / period
    avg_loss = sum(losses[:period]) / period
    for i in range(period, len(gains)):
        avg_gain = (avg_gain * (period - 1) + gains[i]) / period
        avg_loss = (avg_loss * (period - 1) + losses[i]) / period
    if avg_loss == 0:
        return 100.0
    return 100 - 100 / (1 + avg_gain / avg_loss)


def true_ranges(candles):
    out = []
    for i, candle in enumerate(candles):
        prev_close = candles[i - 1]["close"] if i else candle["close"]
        out.append(max(candle["high"] - candle["low"], abs(candle["high"] - prev_close), abs(candle["low"] - prev_close)))
    return out


def wilder_average(values, period):
    if len(values) < period:
        return None
    value = sum(values[:period]) / period
    for x in values[period:]:
        value = (value * (period - 1) + x) / period
    return value


def adx(candles, period=14):
    if len(candles) < period * 2 + 1:
        return None
    plus_dm, minus_dm, trs = [], [], []
    for i in range(1, len(candles)):
        up = candles[i]["high"] - candles[i - 1]["high"]
        down = candles[i - 1]["low"] - candles[i]["low"]
        plus_dm.append(up if up > down and up > 0 else 0.0)
        minus_dm.append(down if down > up and down > 0 else 0.0)
        trs.append(max(candles[i]["high"] - candles[i]["low"], abs(candles[i]["high"] - candles[i - 1]["close"]), abs(candles[i]["low"] - candles[i - 1]["close"])))
    atr_value = wilder_average(trs, period)
    if not atr_value:
        return None
    p = wilder_average(plus_dm, period) or 0
    m = wilder_average(minus_dm, period) or 0
    dx_values = []
    for i in range(period, len(trs)):
        if i == period:
            sm_tr, sm_p, sm_m = sum(trs[:period]), sum(plus_dm[:period]), sum(minus_dm[:period])
        else:
            sm_tr = sm_tr - sm_tr / period + trs[i]
            sm_p = sm_p - sm_p / period + plus_dm[i]
            sm_m = sm_m - sm_m / period + minus_dm[i]
        pdi = 100 * sm_p / sm_tr if sm_tr else 0
        mdi = 100 * sm_m / sm_tr if sm_tr else 0
        denom = pdi + mdi
        dx_values.append(100 * abs(pdi - mdi) / denom if denom else 0)
    return wilder_average(dx_values, period)


def analyze(candles):
    """Multi-factor technical model. Score is a confluence index, never a win probability."""
    if len(candles) < 80:
        return {"status": "warming_up", "message": "Waiting for at least 80 candles.", "direction": "NEUTRAL", "score": 0, "max_score": 100}

    closes = [x["close"] for x in candles]
    highs = [x["high"] for x in candles]
    lows = [x["low"] for x in candles]
    last, prev, prev2 = candles[-1], candles[-2], candles[-3]
    e9, e20, e50, e100 = (ema(closes, p) for p in (9, 20, 50, 100))
    momentum = rsi(closes, 14)
    ranges = true_ranges(candles)
    atr_value = wilder_average(ranges, 14) or 0
    adx_value = adx(candles, 14)
    macd_line = (ema(closes, 12) or 0) - (ema(closes, 26) or 0)
    macd_series = [((ema(closes[:i + 1], 12) or 0) - (ema(closes[:i + 1], 26) or 0)) for i in range(25, len(closes))]
    macd_signal = ema(macd_series, 9) or 0.0
    macd_hist = macd_line - macd_signal
    bb_mid = sum(closes[-20:]) / 20
    variance = sum((x - bb_mid) ** 2 for x in closes[-20:]) / 20
    bb_width = 2 * (variance ** 0.5)
    bb_upper, bb_lower = bb_mid + bb_width, bb_mid - bb_width
    bb_position = (last["close"] - bb_lower) / (bb_upper - bb_lower) if bb_upper > bb_lower else 0.5

    swing_high = max(highs[-21:-1])
    swing_low = min(lows[-21:-1])
    micro_high = max(highs[-7:-1])
    micro_low = min(lows[-7:-1])
    bull_bos = last["close"] > swing_high
    bear_bos = last["close"] < swing_low
    bull_sweep = last["low"] < min(lows[-12:-1]) and last["close"] > min(lows[-12:-1])
    bear_sweep = last["high"] > max(highs[-12:-1]) and last["close"] < max(highs[-12:-1])
    bull_choch = e20 < e50 and last["close"] > micro_high
    bear_choch = e20 > e50 and last["close"] < micro_low
    bull_fvg = last["low"] > candles[-3]["high"]
    bear_fvg = last["high"] < candles[-3]["low"]

    body = abs(last["close"] - last["open"])
    candle_range = max(last["high"] - last["low"], 1e-9)
    lower_wick = min(last["open"], last["close"]) - last["low"]
    upper_wick = last["high"] - max(last["open"], last["close"])
    bull_engulf = last["close"] > last["open"] and prev["close"] < prev["open"] and last["close"] >= prev["open"] and last["open"] <= prev["close"]
    bear_engulf = last["close"] < last["open"] and prev["close"] > prev["open"] and last["close"] <= prev["open"] and last["open"] >= prev["close"]
    bull_rejection = lower_wick / candle_range >= 0.42 and last["close"] > last["open"] and body / candle_range >= 0.18
    bear_rejection = upper_wick / candle_range >= 0.42 and last["close"] < last["open"] and body / candle_range >= 0.18
    bull_candle, bear_candle = bull_engulf or bull_rejection, bear_engulf or bear_rejection

    trend_up = bool(e20 and e50 and e100 and e20 > e50 > e100)
    trend_down = bool(e20 and e50 and e100 and e20 < e50 < e100)
    slope_up = bool(e20 and closes[-1] > closes[-4] and e20 > (ema(closes[:-3], 20) or e20))
    slope_down = bool(e20 and closes[-1] < closes[-4] and e20 < (ema(closes[:-3], 20) or e20))
    rsi_bull = momentum is not None and 52 <= momentum <= 70
    rsi_bear = momentum is not None and 30 <= momentum <= 48
    macd_bull, macd_bear = macd_hist > 0, macd_hist < 0
    adx_trending = adx_value is not None and adx_value >= 18
    atr_pct = atr_value / max(last["close"], 1e-9)
    volatility = "EXTREME" if atr_pct > 0.012 else "HIGH" if atr_pct > 0.006 else "NORMAL" if atr_pct > 0 else "UNKNOWN"
    atr_sane = atr_value > 0 and atr_pct < 0.02

    # Weighted 100-point directional confluence. Opposing evidence subtracts points.
    bull = (18 if trend_up else 0) + (7 if slope_up else 0) + (11 if macd_bull else 0) + (8 if rsi_bull else 0) + (14 if bull_bos else 0) + (10 if bull_sweep else 0) + (8 if bull_candle else 0) + (7 if bull_fvg else 0) + (5 if last["close"] > (e20 or last["close"]) else 0) + (7 if adx_trending else 0) + (5 if atr_sane else 0)
    bear = (18 if trend_down else 0) + (7 if slope_down else 0) + (11 if macd_bear else 0) + (8 if rsi_bear else 0) + (14 if bear_bos else 0) + (10 if bear_sweep else 0) + (8 if bear_candle else 0) + (7 if bear_fvg else 0) + (5 if last["close"] < (e20 or last["close"]) else 0) + (7 if adx_trending else 0) + (5 if atr_sane else 0)
    # Penalize chasing extreme Bollinger extension and ambiguous direction.
    if bb_position > 1.08: bull -= 6
    if bb_position < -0.08: bear -= 6
    if rsi_bull and momentum > 74: bull -= 8
    if rsi_bear and momentum < 26: bear -= 8
    bull, bear = max(0, min(100, bull)), max(0, min(100, bear))
    margin = abs(bull - bear)
    direction = "BUY" if bull > bear and margin >= 10 else "SELL" if bear > bull and margin >= 10 else "NEUTRAL"
    score = max(bull, bear) if direction != "NEUTRAL" else max(bull, bear)

    # ATR + recent structure stop, with 1R/2R/3R targets.
    if direction == "BUY":
        entry = last["close"]
        stop = min(entry - 1.35 * atr_value, min(lows[-8:]) - 0.10 * atr_value)
        risk = max(entry - stop, 0.5 * atr_value)
        levels = {"entry": entry, "sl": stop, "tp1": entry + risk, "tp2": entry + 2 * risk, "tp3": entry + 3 * risk}
    elif direction == "SELL":
        entry = last["close"]
        stop = max(entry + 1.35 * atr_value, max(highs[-8:]) + 0.10 * atr_value)
        risk = max(stop - entry, 0.5 * atr_value)
        levels = {"entry": entry, "sl": stop, "tp1": entry - risk, "tp2": entry - 2 * risk, "tp3": entry - 3 * risk}
    else:
        risk = None
        levels = {"entry": None, "sl": None, "tp1": None, "tp2": None, "tp3": None}

    reasons = []
    checks = [
        ("EMA 20/50/100 trend stack", trend_up if direction == "BUY" else trend_down),
        ("EMA slope / directional momentum", slope_up if direction == "BUY" else slope_down),
        ("MACD momentum confirmation", macd_bull if direction == "BUY" else macd_bear),
        ("RSI momentum zone", rsi_bull if direction == "BUY" else rsi_bear),
        ("Swing break of structure", bull_bos if direction == "BUY" else bear_bos),
        ("Liquidity sweep and reclaim", bull_sweep if direction == "BUY" else bear_sweep),
        ("Candle rejection / engulfing", bull_candle if direction == "BUY" else bear_candle),
        ("Fair value gap", bull_fvg if direction == "BUY" else bear_fvg),
        ("ADX trend strength", adx_trending),
    ]
    if direction in ("BUY", "SELL"):
        reasons = [name for name, passed in checks if passed]
    grade = "A+" if score >= 82 and margin >= 22 else "A" if score >= 74 and margin >= 18 else "B" if score >= 65 and margin >= 14 else "C" if score >= 55 else "D"
    guidance = "WAIT — directional edge is unclear" if direction == "NEUTRAL" or score < 55 else "DEVELOPING — wait for structure and timeframe confirmation" if score < 65 else "WATCH — confirmation required; check spread and risk" if score < 74 else "HIGH CONFLUENCE — verify closed candle, higher timeframes and execution costs"
    return {
        "status": "ok", "direction": direction, "score": int(score), "max_score": 100,
        "bull_score": int(bull), "bear_score": int(bear), "score_margin": int(margin), "grade": grade,
        "rsi": round(momentum, 1) if momentum is not None else None,
        "ema_fast": e20, "ema_slow": e50, "ema_long": e100,
        "macd_histogram": macd_hist, "adx": round(adx_value, 1) if adx_value is not None else None,
        "bb_position": round(bb_position, 2), "atr": atr_value, "risk_points": risk,
        "risk_reward": "1:1 / 1:2 / 1:3", "volatility": volatility,
        "liquidity": "LOW SWEEP" if bull_sweep else "HIGH SWEEP" if bear_sweep else "No sweep detected",
        "structure": "BULLISH BOS" if bull_bos else "BEARISH BOS" if bear_bos else "No confirmed break",
        "choch": "BULLISH CHoCH" if bull_choch else "BEARISH CHoCH" if bear_choch else "No CHoCH",
        "fvg": "BULLISH FVG" if bull_fvg else "BEARISH FVG" if bear_fvg else "None detected",
        "candle_pattern": "Bullish engulfing" if bull_engulf else "Bearish engulfing" if bear_engulf else "Bullish rejection" if bull_rejection else "Bearish rejection" if bear_rejection else "No clear pattern",
        "reasons": reasons, "setup_quality": grade, "guidance": guidance,
        "signal_status": "DEVELOPING" if score >= 55 and direction != "NEUTRAL" else "WAITING",
        **levels
    }

def fetch_candles(interval, outputsize=220, retries=None):
    if not API_KEY:
        raise RuntimeError("Missing TWELVEDATA_API_KEY. Add your Twelve Data API key to the hosting environment.")
    started = time.perf_counter()
    params = {"symbol": SYMBOL, "interval": interval, "outputsize": outputsize,
              "timezone": "UTC", "apikey": API_KEY}
    retry_limit = PROVIDER_RETRIES if retries is None else max(0, int(retries))
    for attempt in range(retry_limit + 1):
        try:
            r = requests.get("https://api.twelvedata.com/time_series", params=params,
                             timeout=(3.5, PROVIDER_TIMEOUT), headers={"Accept": "application/json", "User-Agent": "XAUUSD-Black-Pro/12"})
            break
        except (requests.Timeout, requests.ConnectionError) as exc:
            last_error = exc
            if attempt >= retry_limit:
                raise RuntimeError(f"Twelve Data connection failed after {attempt + 1} attempt(s): {type(exc).__name__}. Check provider availability, API limits and Render outbound connectivity.") from exc
            time.sleep(0.6 * (attempt + 1))
    try:
        data = r.json()
    except ValueError:
        raise RuntimeError(f"Twelve Data returned a non-JSON response (HTTP {r.status_code}).")
    if not isinstance(data, dict) or r.status_code != 200 or "values" not in data:
        detail = data.get("message", "Market data provider error") if isinstance(data, dict) else "Invalid provider response"
        code = data.get("code", r.status_code) if isinstance(data, dict) else r.status_code
        raise RuntimeError(f"Twelve Data {code}: {detail}")
    vals = list(reversed(data["values"]))
    candles = []
    for v in vals:
        stamp = v["datetime"]
        if "T" in stamp:
            dt = datetime.fromisoformat(stamp.replace("Z", "+00:00"))
            if dt.tzinfo is None: dt = dt.replace(tzinfo=timezone.utc)
        else:
            dt = datetime.strptime(stamp, "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone.utc)
        candle = {"time": int(dt.timestamp()), "open": float(v["open"]),
            "high": float(v["high"]), "low": float(v["low"]),
            "close": float(v["close"]), "volume": float(v.get("volume") or 0)}
        if not all(candle[k] > 0 for k in ("open", "high", "low", "close")):
            continue
        if candle["high"] < max(candle["open"], candle["close"], candle["low"]) or candle["low"] > min(candle["open"], candle["close"], candle["high"]):
            continue
        candles.append(candle)
    if len(candles) < 80:
        raise RuntimeError(f"Provider returned only {len(candles)} valid candles; at least 80 are required for analysis.")
    return candles

def get_market(force=False):
    """Return a cached snapshot; refresh base and expired higher frames concurrently."""
    now = time.time()
    if not force and CACHE["payload"] and now - CACHE["at"] < CACHE_SECONDS:
        return CACHE["payload"], None
    with MARKET_LOCK:
        now = time.time()
        if not force and CACHE["payload"] and now - CACHE["at"] < CACHE_SECONDS:
            return CACHE["payload"], None
        started = time.perf_counter()
        try:
            # Fetch the primary chart first. Optional higher-timeframe requests must never
            # prevent a valid 1-minute chart from loading.
            candles = fetch_candles(INTERVAL, 250)
            frames = {INTERVAL: analyze(candles)}
            with HTF_LOCK:
                refresh_htf = now - HTF_CACHE["at"] >= 90 or not HTF_CACHE["frames"]
                if refresh_htf:
                    with ThreadPoolExecutor(max_workers=2) as pool:
                        futures = {tf: pool.submit(fetch_candles, tf, 180, 0) for tf in ("15min", "1h")}
                        refreshed = {}
                        for tf, future in futures.items():
                            try:
                                refreshed[tf] = analyze(future.result())
                            except Exception as exc:
                                refreshed[tf] = {"status": "unavailable", "message": str(exc)}
                    # Retain previously verified HTF snapshots when a context request fails.
                    previous = HTF_CACHE.get("frames", {})
                    HTF_CACHE["frames"] = {tf: (refreshed.get(tf) if refreshed.get(tf, {}).get("status") == "ok" else previous.get(tf, refreshed.get(tf))) for tf in ("15min", "1h")}
                    HTF_CACHE["at"] = now
                frames.update(HTF_CACHE["frames"])
            analysis = frames[INTERVAL]
            higher = [x.get("direction") for k, x in frames.items() if k != INTERVAL and x.get("status") == "ok"]
            alignment = sum(1 for direction in higher if direction == analysis.get("direction") and direction != "NEUTRAL")
            opposition = sum(1 for direction in higher if direction in ("BUY", "SELL") and direction != analysis.get("direction")) if analysis.get("direction") != "NEUTRAL" else 0
            analysis["timeframes"] = {k: {"direction": v.get("direction", "N/A"), "score": v.get("score"), "grade": v.get("grade", "—")} for k, v in frames.items()}
            analysis["higher_timeframe_alignment"] = alignment
            analysis["higher_timeframe_opposition"] = opposition
            analysis["mtf_status"] = "FULL ALIGNMENT" if alignment == 2 else "PARTIAL ALIGNMENT" if alignment == 1 and opposition == 0 else "TIMEFRAME CONFLICT" if opposition else "UNCONFIRMED"
            # Any opposing higher timeframe blocks a confirmed signal.
            if analysis.get("direction") in ("BUY", "SELL") and opposition > 0:
                analysis["signal_status"] = "CONFLICT"
                analysis["guidance"] = "WAIT — higher-timeframe direction is conflicting"
            elif analysis.get("direction") in ("BUY", "SELL") and analysis.get("volatility") == "EXTREME":
                analysis["signal_status"] = "RISK FILTER"
                analysis["guidance"] = "WAIT — volatility is unusually elevated; reduce risk and wait for conditions to normalize"
            elif analysis.get("direction") in ("BUY", "SELL") and (analysis.get("adx") or 0) < 16:
                analysis["signal_status"] = "WEAK TREND"
                analysis["guidance"] = "WAIT — trend strength is weak; avoid forcing a directional setup"
            elif analysis.get("direction") in ("BUY", "SELL") and alignment < 1:
                analysis["signal_status"] = "DEVELOPING"
            else:
                analysis["signal_status"] = "CONFIRMATION-READY" if analysis.get("score", 0) >= 72 else analysis.get("signal_status", "WAITING")
            payload = {
                "symbol": SYMBOL, "interval": INTERVAL, "candles": candles,
                "analysis": analysis, "provider": "Twelve Data", "updated_at": datetime.now(timezone.utc).isoformat(),
                "data_age_seconds": 0, "refresh_interval_seconds": CACHE_SECONDS,
                "provider_latency_ms": round((time.perf_counter() - started) * 1000),
                "provider_candle_time": candles[-1]["time"] if candles else None,
                "provider_candle_age_seconds": max(0, int(time.time() - candles[-1]["time"])) if candles else None,
                "timeframes_updated_at": datetime.fromtimestamp(HTF_CACHE["at"], timezone.utc).isoformat()
            }
            CACHE.update({"at": time.time(), "payload": payload})
            LAST_PROVIDER_ERROR.update({"message": None, "at": None})
            return payload, None
        except Exception as exc:
            LAST_PROVIDER_ERROR.update({"message": str(exc), "at": datetime.now(timezone.utc).isoformat()})
            age = max(0, time.time() - CACHE["at"]) if CACHE["at"] else float("inf")
            if CACHE["payload"] and age <= STALE_MAX_SECONDS:
                stale = dict(CACHE["payload"])
                stale["stale"] = True
                stale["data_age_seconds"] = round(age)
                stale["market_status"] = "STALE DATA — provider refresh failed"
                stale["provider_error"] = str(exc)
                stale["analysis"] = dict(stale.get("analysis", {}))
                stale["analysis"]["signal_status"] = "PAUSED — STALE DATA"
                stale["analysis"]["guidance"] = "WAIT — feed refresh failed; do not act on this old setup"
                return stale, None
            return None, f"Could not retrieve fresh market data: {str(exc)}"

def log_background_signal(event, a, detail=""):
    with db() as c:
        c.execute("""INSERT INTO signals (created_at,symbol,event,direction,score,entry,stop,tp1,tp2,tp3,details)
            VALUES (?,?,?,?,?,?,?,?,?,?,?)""", (datetime.now(timezone.utc).isoformat(), SYMBOL, event,
            a.get("direction", ""), a.get("score"), a.get("entry"), a.get("sl"), a.get("tp1"),
            a.get("tp2"), a.get("tp3"), detail or a.get("mtf_status", "")))

def send_push(title, body, url="/"):
    if not (webpush and os.getenv("VAPID_PRIVATE_KEY") and os.getenv("VAPID_PUBLIC_KEY")):
        return
    with db() as c: subs = c.execute("SELECT endpoint,subscription FROM push_subscriptions").fetchall()
    for row in subs:
        try:
            webpush(subscription_info=json.loads(row["subscription"]), data=json.dumps({"title":title,"body":body,"url":url}),
                vapid_private_key=os.environ["VAPID_PRIVATE_KEY"],
                vapid_claims={"sub":os.getenv("VAPID_CLAIMS_EMAIL","mailto:admin@example.com")})
        except WebPushException as exc:
            if getattr(exc, "response", None) is not None and exc.response.status_code in (404,410):
                with db() as c: c.execute("DELETE FROM push_subscriptions WHERE endpoint=?", (row["endpoint"],))
            log.warning("Push delivery failed: %s", exc)
        except Exception as exc: log.warning("Push error: %s", exc)

def background_monitor():
    interval = max(12, int(os.getenv("MONITOR_INTERVAL_SECONDS", "15")))
    while True:
        try:
            payload, error = get_market()
            if payload and not payload.get("stale") and payload["analysis"].get("status") == "ok":
                a = payload["analysis"]; candle = payload["candles"][-1]
                key = f"{candle['time']}:{a.get('direction')}"
                with db() as c:
                    old = c.execute("SELECT value FROM monitor_state WHERE key='last_signal_key'").fetchone()
                # Resolve active setup outcomes using each newly fetched candle. If SL and TP1
                # are both touched in the same OHLC candle, use the conservative SL-first rule.
                with db() as c:
                    open_rows = c.execute("SELECT * FROM tracked_setups WHERE outcome='OPEN'").fetchall()
                    for trade in open_rows:
                        if candle["time"] <= trade["candle_time"]: continue
                        result = None
                        if trade["direction"] == "BUY":
                            if candle["low"] <= trade["stop"]: result = "SL"
                            elif candle["high"] >= trade["tp1"]: result = "TP1"
                        else:
                            if candle["high"] >= trade["stop"]: result = "SL"
                            elif candle["low"] <= trade["tp1"]: result = "TP1"
                        if result:
                            c.execute("UPDATE tracked_setups SET outcome=?,closed_at=? WHERE id=?", (result, datetime.now(timezone.utc).isoformat(), trade["id"]))
                            c.execute("INSERT INTO signals(created_at,symbol,event,direction,entry,stop,tp1,details) VALUES(?,?,?,?,?,?,?,?)", (datetime.now(timezone.utc).isoformat(), SYMBOL, trade["direction"] + " " + result, trade["direction"], trade["entry"], trade["stop"], trade["tp1"], "Outcome tracker"))
                direction = a.get("direction")
                # Early heads-up from the currently forming candle; deduped per candle/direction.
                early_key = f"early:{candle['time']}:{direction}"
                with db() as c:
                    early_old = c.execute("SELECT value FROM monitor_state WHERE key='last_early_key'").fetchone()
                if direction in ("BUY", "SELL") and a.get("score", 0) >= 55 and a.get("signal_status") not in ("CONFLICT", "RISK FILTER", "WEAK TREND") and (not early_old or early_old["value"] != early_key):
                    early_event = "EARLY " + direction
                    log_background_signal(early_event, a, "Forming-candle watch · not confirmed")
                    with db() as c: c.execute("INSERT OR REPLACE INTO monitor_state(key,value) VALUES('last_early_key',?)", (early_key,))
                    send_push("XAUUSD " + early_event, f"Developing setup · confluence {a['score']}/100. Wait for candle close and confirmation.")
                if INTERVAL.endswith("min"):
                    candle_seconds = int(INTERVAL[:-3]) * 60
                elif INTERVAL.endswith("h"):
                    candle_seconds = int(INTERVAL[:-1]) * 3600
                else:
                    candle_seconds = 300
                candle_closed = time.time() >= candle["time"] + candle_seconds + 2
                if candle_closed and direction in ("BUY", "SELL") and a.get("score",0) >= 72 and a.get("higher_timeframe_alignment",0) >= 1 and a.get("higher_timeframe_opposition",0) == 0 and a.get("volatility") != "EXTREME" and (a.get("adx") or 0) >= 16 and (not old or old["value"] != key):
                    event = direction + " CONFIRMED"
                    log_background_signal(event, a, "Closed-candle confirmation · " + a.get("mtf_status", ""))
                    if all(a.get(k) is not None for k in ("entry", "sl", "tp1")):
                        with db() as c: c.execute("INSERT INTO tracked_setups(created_at,direction,entry,stop,tp1,tp2,tp3,candle_time) VALUES(?,?,?,?,?,?,?,?)", (datetime.now(timezone.utc).isoformat(), direction, a["entry"], a["sl"], a["tp1"], a.get("tp2"), a.get("tp3"), candle["time"]))
                    with db() as c: c.execute("INSERT OR REPLACE INTO monitor_state(key,value) VALUES('last_signal_key',?)", (key,))
                    send_push("XAUUSD " + event, f"Confluence {a['score']}/100 · MTF {a['mtf_status']} · Entry {a.get('entry')} · SL {a.get('sl')} · TP1 {a.get('tp1')}")
        except Exception as exc: log.exception("Background scan failed: %s", exc)
        time.sleep(interval)


@app.route("/")
def index():
    return render_template("index.html")

@app.route("/manifest.webmanifest")
def manifest():
    return send_from_directory("static", "manifest.webmanifest", mimetype="application/manifest+json")

@app.route("/sw.js")
def service_worker():
    return send_from_directory("static", "sw.js", mimetype="application/javascript")

@app.route("/api/push/config")
def push_config():
    return jsonify({"publicKey": os.getenv("VAPID_PUBLIC_KEY", ""), "enabled": bool(webpush and os.getenv("VAPID_PUBLIC_KEY") and os.getenv("VAPID_PRIVATE_KEY"))})

@app.route("/api/push/subscribe", methods=["POST"])
def push_subscribe():
    d = request.get_json(silent=True) or {}; sub = d.get("subscription")
    if not isinstance(sub, dict) or not sub.get("endpoint"):
        return jsonify({"error":"Invalid push subscription"}), 400
    with db() as c: c.execute("INSERT OR REPLACE INTO push_subscriptions(endpoint,subscription,created_at) VALUES(?,?,?)", (sub["endpoint"], json.dumps(sub), datetime.now(timezone.utc).isoformat()))
    return jsonify({"saved":True})

@app.route("/api/market")
def market():
    payload, error = get_market()
    if error:
        log.warning("Market feed unavailable: %s", error)
        return jsonify({"error": error, "configured": bool(API_KEY), "provider": "Twelve Data"}), 503
    return jsonify(payload)

@app.route("/api/signals")
def signals():
    with db() as c:
        rows = c.execute("SELECT * FROM signals ORDER BY id DESC LIMIT 100").fetchall()
    return jsonify([dict(x) for x in rows])

@app.route("/api/performance")
def performance():
    with db() as c:
        rows = c.execute("SELECT outcome,COUNT(*) AS n FROM tracked_setups WHERE outcome!='OPEN' GROUP BY outcome").fetchall()
        opened = c.execute("SELECT COUNT(*) FROM tracked_setups WHERE outcome='OPEN'").fetchone()[0]
        total = sum(x["n"] for x in rows); wins = sum(x["n"] for x in rows if x["outcome"].startswith("TP")); losses = sum(x["n"] for x in rows if x["outcome"] == "SL")
    return jsonify({"closed":total,"wins":wins,"losses":losses,"open":opened,"win_rate":round(100*wins/total,1) if total else None,"note":"Historical outcomes from monitored OHLC candles; not a verified broker fill or live trading return."})

@app.route("/api/signals/log", methods=["POST"])
def log_signal():
    from flask import request
    d = request.get_json(silent=True) or {}
    allowed = {"EARLY BUY","EARLY SELL","BUY CONFIRMED","SELL CONFIRMED","BUY TP1","BUY TP2","BUY TP3","BUY SL","SELL TP1","SELL TP2","SELL TP3","SELL SL"}
    if d.get("event") not in allowed:
        return jsonify({"error":"Invalid event"}), 400
    with db() as c:
        c.execute("""INSERT INTO signals
            (created_at,symbol,event,direction,score,entry,stop,tp1,tp2,tp3,details)
            VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
            (datetime.now(timezone.utc).isoformat(), SYMBOL, d["event"],
             d.get("direction",""), d.get("score"), d.get("entry"), d.get("sl"),
             d.get("tp1"), d.get("tp2"), d.get("tp3"), d.get("details","")))
    return jsonify({"saved": True})

@app.route("/health")
def health():
    age = round(max(0, time.time() - CACHE["at"])) if CACHE["at"] else None
    return jsonify({"ok": True, "version": "12.0", "market_key_configured": bool(API_KEY), "push_configured": bool(webpush and os.getenv("VAPID_PUBLIC_KEY") and os.getenv("VAPID_PRIVATE_KEY")), "background_monitor": True, "monitor_interval_seconds": max(12, int(os.getenv("MONITOR_INTERVAL_SECONDS", "15"))), "cache_seconds": CACHE_SECONDS, "provider_timeout_seconds": PROVIDER_TIMEOUT, "provider_retries": PROVIDER_RETRIES, "stale_max_seconds": STALE_MAX_SECONDS, "market_interval": INTERVAL, "provider": "Twelve Data", "provider_cache_age_seconds": age, "provider_last_error": LAST_PROVIDER_ERROR["message"], "api_key_configured": bool(API_KEY)})

init_db()
# Single Gunicorn worker is configured in render.yaml so this scanner runs once per service.
_monitor_started = False
_monitor_lock = threading.Lock()
def start_monitor_once():
    global _monitor_started
    with _monitor_lock:
        if not _monitor_started and os.getenv("DISABLE_BACKGROUND_MONITOR", "0") != "1":
            threading.Thread(target=background_monitor, name="xauusd-monitor", daemon=True).start()
            _monitor_started = True
start_monitor_once()
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)), debug=False)

# XAUUSD BLACK PRO V10

Signal-only XAU/USD market analysis dashboard for Render. It does not place trades.

## V10 reliability changes
- Backend market snapshot cache defaults to 60 seconds (minimum 30) to reduce Twelve Data request pressure; the browser may poll more often but receives the cached snapshot.
- Higher-timeframe snapshots refresh every 5 minutes rather than every minute.
- Twelve Data requests use explicit connect/read timeouts and one retry for transient network failures.
- Provider JSON, OHLC values, candle count, and candle freshness are validated before analysis.
- Analysis uses completed candles only. Incomplete or stale feeds return an explicit error rather than a fabricated price or signal.
- `/health` reports provider name, symbol, interval, key-presence status, and cache settings without exposing secrets.
- Technical confluence remains a rule-based score, not a probability or guaranteed outcome.

## Required Render environment variable
`TWELVEDATA_API_KEY` = your own Twelve Data API key. Never put the key in source code or share it in chat.

Optional variables: `MARKET_SYMBOL` (default `XAU/USD`), `MARKET_INTERVAL` (default `5min`), `CACHE_SECONDS` (default `60`, minimum `30`), `MONITOR_INTERVAL_SECONDS` (default `15`).

## Deploy
Build command:
```sh
python -c "import zipfile; zipfile.ZipFile('XAUUSD_Market_Intelligence_PRO_v4_Render_Free.zip').extractall('.') " && pip install -r xauusd_market_intelligence_pro/requirements.txt
```
Start command:
```sh
cd xauusd_market_intelligence_pro && gunicorn app:app --workers 1 --threads 8 --timeout 120
```

After deployment, check `/health` and `/api/market`. A successful deploy alone does not prove that the provider is returning valid live candles.

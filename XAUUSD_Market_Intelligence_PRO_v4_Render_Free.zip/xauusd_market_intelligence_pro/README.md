# XAUUSD BLACK PRO V8

A signal-only XAUUSD market-analysis dashboard for Render. It does not place orders or connect to MetaTrader 5.

## V8 upgrades
- Full black-and-metallic-gold terminal redesign, responsive for mobile and desktop.
- Expanded 100-point rule-based confluence model: EMA 20/50/100 structure, RSI, MACD histogram, ADX trend strength, ATR volatility regime, Bollinger position, swing BOS/CHoCH, liquidity sweep/reclaim, FVG and candle confirmation.
- Higher-timeframe context across 5m, 15m and 1h; 1h opposition downgrades a developing setup.
- Separate developing and confirmed states. Confirmed scanner events require a completed primary candle, a strong confluence score and at least one aligned higher timeframe with no opposing higher-timeframe frame.
- ATR/structure-based indicative stop and 1R/2R/3R target references.
- Signal journal, push notifications and OHLC-based TP1/SL outcome tracking retained.
- Concurrent cold-start market/timeframe fetching and short-lived caching to reduce avoidable request latency.

## Important limitations
- The 0–100 score is a transparent technical-confluence index, not a probability, expected return, or calibrated win rate.
- More filters can reduce false positives but can also reduce signal frequency. No indicator stack guarantees better trades.
- Data refresh speed depends on the Twelve Data plan, provider publication cadence, network latency and Render uptime. Browser polling does not create new market ticks.
- The background scanner runs approximately every 15 seconds by default while the service is awake. Render Free services can sleep; a sleeping service cannot continuously scan or send alerts.
- TP/SL outcome tracking uses candle OHLC and cannot determine intrabar order when both levels are crossed in one candle. It does not model spread, slippage, commissions, or broker fills.
- Use this as research/education only. Verify every setup and manage risk independently.

## Render deployment
Build command: `pip install -r requirements.txt`

Start command: `gunicorn app:app --workers 1 --threads 8 --timeout 120`

Required environment variable: `TWELVEDATA_API_KEY`

Optional push notification variables: `VAPID_PUBLIC_KEY`, `VAPID_PRIVATE_KEY`, `VAPID_CLAIMS_EMAIL`

Optional tuning: `MARKET_SYMBOL` (default `XAU/USD`), `MARKET_INTERVAL` (default `5min`), `CACHE_SECONDS` (default 10; minimum 8), `MONITOR_INTERVAL_SECONDS` (default 15; minimum 12), `DATABASE_PATH` (default `signals.db`).

For reliable persistent signal history, configure a persistent disk or managed database and an always-on service. The supplied Render Blueprint keeps the existing free-tier setting to avoid silently changing billing.

## V11 speed and data integrity notes
- Default base timeframe is 1 minute (`MARKET_INTERVAL=1min`); higher-timeframe checks remain 15m and 1h.
- Dashboard checks the cached server snapshot every 3 seconds. Provider requests remain cache-limited to avoid rate-limit abuse (default 10 seconds).
- This is not tick streaming. Update speed depends on Twelve Data plan, provider publication, network, and Render uptime.
- Configure `TWELVEDATA_API_KEY` in Render. Never put the key in source code.
- V11 validates returned OHLC candles and refuses to fabricate missing prices.
- Confluence scores are not win probabilities. Signals are informational only; no broker orders are placed.

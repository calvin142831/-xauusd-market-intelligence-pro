# XAUUSD Market Intelligence PRO v4

An installable iPhone-friendly Progressive Web App (PWA) and desktop web dashboard for XAU/USD analysis. It is an **analysis and alerting tool, not an automated trading bot**.

## v4 features
- Responsive chart dashboard and Home Screen installation on iPhone/iPad.
- Twelve Data XAU/USD candles with configurable 5-minute primary timeframe.
- 5-minute, 15-minute and 1-hour technical confluence comparison (EMA, RSI, ATR, liquidity sweep, BOS and FVG rules).
- Server-side background scanning while the hosted service is running; it does not depend on the dashboard being open.
- Early browser warnings, confirmed confluence alerts, and optional Web Push notifications.
- Signal history and a basic TP1/SL outcome tracker based on candle OHLC data.
- SQLite persistence on the configured Render disk.

## Important limitations
- The score is a transparent rule-based confluence score, **not** an AI model, calibrated probability, or win-rate prediction.
- TP/SL outcome tracking uses candle highs/lows, not broker fills, bid/ask spread, slippage, commissions, or intrabar tick sequence. If both SL and TP1 are touched in one candle, the tracker conservatively records SL first.
- Multi-timeframe requests use three provider calls per scan. Check Twelve Data plan limits and symbol availability. The data may be delayed depending on the plan.
- Background scanning only runs while the Render service is running. Use an always-on paid service; free hosting may sleep. The monitor scans at `MONITOR_INTERVAL_SECONDS` (default 60).
- iPhone Web Push requires iOS/iPadOS 16.4 or later, HTTPS, the site added to the Home Screen, notification permission, and valid VAPID keys. Push delivery is not guaranteed by Apple or the hosting provider.
- This does not place trades, connect to a broker, guarantee signals, or guarantee profits. Early warnings may change or disappear.

## Deploy on Render
1. Create a Twelve Data account and obtain an API key with access to `XAU/USD` and the requested intervals.
2. Upload this folder to a GitHub repository.
3. Create a Render Web Service from the repository. Render reads `render.yaml`.
4. Set `TWELVEDATA_API_KEY` in the Render environment. Keep it private; do not put it in frontend code.
5. For push notifications, generate a VAPID key pair (see below), then set `VAPID_PUBLIC_KEY`, `VAPID_PRIVATE_KEY`, and `VAPID_CLAIMS_EMAIL` in Render.
6. Deploy. The Render service is configured as an always-on Starter instance with a persistent disk for SQLite. This free trial configuration uses Render’s free web service. Free services can sleep and do not provide persistent disk; upgrade for dependable always-on monitoring and durable history.

### Generate VAPID keys
Run this locally in a Python environment with `cryptography` installed:

```python
import base64
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives import serialization
key = ec.generate_private_key(ec.SECP256R1())
private_pem = key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption()).decode()
pub = key.public_key().public_bytes(serialization.Encoding.X962, serialization.PublicFormat.UncompressedPoint)
b64url = lambda b: base64.urlsafe_b64encode(b).rstrip(b'=').decode()
print('VAPID_PRIVATE_KEY (PEM):\n' + private_pem)
print('VAPID_PUBLIC_KEY=' + b64url(pub))
```

Put the full PEM value in `VAPID_PRIVATE_KEY` and the one-line value in `VAPID_PUBLIC_KEY`. Set a real contact email in `VAPID_CLAIMS_EMAIL`, for example `mailto:you@example.com`.

## Add to iPhone
1. Deploy the app to its HTTPS Render URL.
2. Open that URL in **Safari** on the iPhone.
3. Tap **Share** → **Add to Home Screen** → **Add**.
4. Launch the new XAUUSD PRO icon from the Home Screen.
5. Tap **Enable alerts** and allow notifications. Push will work only after VAPID keys are configured on the server.

## Run locally
```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
export TWELVEDATA_API_KEY="your_key_here"
python app.py
```
Open `http://localhost:5000`. Push notifications require HTTPS and configured VAPID keys, so test them on the deployed HTTPS site.

## Environment variables
- `TWELVEDATA_API_KEY` (required)
- `MARKET_SYMBOL` (default `XAU/USD`)
- `MARKET_INTERVAL` (default `5min`)
- `CACHE_SECONDS` (default `15`)
- `MONITOR_INTERVAL_SECONDS` (default `60`)
- `DATABASE_PATH` (Render config uses `/var/data/signals.db`)
- `VAPID_PUBLIC_KEY`, `VAPID_PRIVATE_KEY`, `VAPID_CLAIMS_EMAIL` (push setup)
